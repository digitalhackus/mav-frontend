
  # Login & Authentication Screen

  This is a code bundle for Login & Authentication Screen. The original project is available at https://www.figma.com/design/aDFJEoQykprmzCeC32sY27/Login---Authentication-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  