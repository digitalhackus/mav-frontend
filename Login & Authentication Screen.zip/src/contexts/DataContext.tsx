import { createContext, useContext, useState, ReactNode } from 'react';

// Types
export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  price: number;
  type: 'service' | 'product';
  customerSupplied?: boolean;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customer: string;
  customerId: string;
  customerEmail?: string;
  customerPhone: string;
  make: string;
  model: string;
  plate: string;
  date: string;
  amount: number;
  status: 'Paid' | 'Pending' | 'Draft';
  paymentMethod: string;
  servicesCount: number;
  technician?: string;
  supervisor?: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  discount: number;
  discountPercentage?: number;
  taxPercentage?: number;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone: string;
  address?: string;
  vehicles: number;
  lastVisit: string;
  totalSpent: number;
  status: 'Active' | 'VIP' | 'Inactive';
  serviceHistory: number;
  invoiceHistory?: string[]; // Array of invoice IDs
}

// Inventory Types
export interface Product {
  id: string;
  name: string;
  category: string;
  salePrice: number;
  lastCostPrice: number;
  averageCostPrice: number;
  stockQuantity: number;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  vendorId?: string;
  vendorName?: string;
}

export interface Vendor {
  id: string;
  name: string;
  phone?: string;
  notes?: string;
  outstandingBalance: number;
  totalSupplied: number;
  totalPaid: number;
  lastSupplyDate?: string;
  lastPaymentDate?: string;
}

export interface StockInItem {
  productId: string;
  productName: string;
  quantity: number;
  costPrice: number;
  total: number;
}

export interface StockInRecord {
  id: string;
  vendorId: string;
  vendorName: string;
  date: string;
  items: StockInItem[];
  totalAmount: number;
}

export interface VendorPayment {
  id: string;
  vendorId: string;
  date: string;
  amount: number;
  method: string;
  notes?: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  category?: string;
}

interface DataContextType {
  invoices: Invoice[];
  customers: Customer[];
  products: Product[];
  services: Service[];
  vendors: Vendor[];
  stockInRecords: StockInRecord[];
  vendorPayments: VendorPayment[];
  
  // Invoice Operations (The "Backend" logic)
  addInvoice: (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber' | 'date' | 'servicesCount'>) => Invoice;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  getInvoiceById: (id: string) => Invoice | undefined;
  
  // Customer Operations
  addCustomer: (customer: Omit<Customer, 'id' | 'lastVisit' | 'totalSpent' | 'serviceHistory' | 'vehicles'>) => Customer;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  getCustomerById: (id: string) => Customer | undefined;
  
  // Product/Inventory Operations
  addProduct: (product: Omit<Product, 'id' | 'status'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  deductStock: (productId: string, quantity: number) => void;

  // Service Operations
  addService: (service: Omit<Service, 'id'>) => Service;
  updateService: (id: string, updates: Partial<Service>) => void;
  deleteService: (id: string) => void;
  
  // Vendor Operations
  addVendor: (vendor: Omit<Vendor, 'id' | 'outstandingBalance' | 'totalSupplied' | 'totalPaid'>) => Vendor;
  updateVendor: (id: string, updates: Partial<Vendor>) => void;
  deleteVendor: (id: string) => void;
  getVendorById: (id: string) => Vendor | undefined;
  
  // Stock In Operations
  addStockIn: (stockIn: Omit<StockInRecord, 'id' | 'date'>) => StockInRecord;
  getVendorStockIns: (vendorId: string) => StockInRecord[];
  
  // Payment Operations
  addVendorPayment: (payment: Omit<VendorPayment, 'id' | 'date'>) => VendorPayment;
  getVendorPayments: (vendorId: string) => VendorPayment[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Initial mock data
const initialInvoices: Invoice[] = [
  {
    id: "001",
    invoiceNumber: "INV-001",
    customer: "John Smith",
    customerId: "CUST-001",
    customerEmail: "john.smith@email.com",
    customerPhone: "+92 300 1234567",
    make: "Toyota",
    model: "Corolla",
    plate: "ISB-1234",
    date: "2026-01-20",
    amount: 11800,
    status: "Paid",
    paymentMethod: "Card/POS",
    servicesCount: 3,
    technician: "Ahmad Ali",
    supervisor: "Hassan Khan",
    subtotal: 10000,
    tax: 1800,
    discount: 0,
    items: [
      { id: "1", description: "Oil Change + Filter", quantity: 1, price: 4500, type: 'service' },
      { id: "2", description: "Brake Pad Replacement", quantity: 1, price: 6800, type: 'service' },
      { id: "3", description: "General Inspection", quantity: 1, price: 500, type: 'service' },
    ]
  },
  {
    id: "002",
    invoiceNumber: "INV-002",
    customer: "Sarah Johnson",
    customerId: "CUST-002",
    customerEmail: "sarah.j@email.com",
    customerPhone: "+92 321 2345678",
    make: "Honda",
    model: "Civic",
    plate: "ISB-5678",
    date: "2026-01-25",
    amount: 5200,
    status: "Pending",
    paymentMethod: "Cash",
    servicesCount: 2,
    technician: "Usman Shah",
    supervisor: "Hassan Khan",
    subtotal: 5200,
    tax: 0,
    discount: 0,
    items: [
      { id: "1", description: "Tire Rotation", quantity: 1, price: 800, type: 'service' },
      { id: "2", description: "Wheel Alignment", quantity: 1, price: 1500, type: 'service' },
      { id: "3", description: "Air Filter Replacement", quantity: 1, price: 380, type: 'service' },
    ]
  }
];

const initialCustomers: Customer[] = [
  {
    id: "CUST-001",
    name: "John Smith",
    email: "john.smith@email.com",
    phone: "+92 300 1234567",
    address: "123 Main St, Islamabad",
    vehicles: 2,
    lastVisit: "2026-01-20",
    totalSpent: 11800,
    status: "Active",
    serviceHistory: 8,
    invoiceHistory: ["001"]
  },
  {
    id: "CUST-002",
    name: "Sarah Johnson",
    email: "sarah.j@email.com",
    phone: "+92 321 2345678",
    address: "456 Oak Ave, Lahore",
    vehicles: 1,
    lastVisit: "2026-01-25",
    totalSpent: 5200,
    status: "Active",
    serviceHistory: 12,
    invoiceHistory: ["002"]
  }
];

const initialProducts: Product[] = [
  {
    id: "PROD-001",
    name: "Engine Oil 5W-30",
    category: "Oils & Lubricants",
    salePrice: 2500,
    lastCostPrice: 1800,
    averageCostPrice: 1800,
    stockQuantity: 45,
    status: "In Stock"
  },
  {
    id: "PROD-002",
    name: "Oil Filter",
    category: "Filters",
    salePrice: 800,
    lastCostPrice: 500,
    averageCostPrice: 500,
    stockQuantity: 60,
    status: "In Stock"
  },
  {
    id: "PROD-004",
    name: "Air Filter",
    category: "Filters",
    salePrice: 650,
    lastCostPrice: 380,
    averageCostPrice: 380,
    stockQuantity: 8,
    status: "Low Stock"
  }
];

const initialVendors: Vendor[] = [
  {
    id: "VEN-001",
    name: "AutoParts Supply Co.",
    phone: "+92 300 9876543",
    notes: "Main supplier for filters and oils",
    outstandingBalance: 45000,
    totalSupplied: 250000,
    totalPaid: 205000,
    lastSupplyDate: "2026-01-15",
    lastPaymentDate: "2026-01-10"
  }
];

const initialServices: Service[] = [
  { id: "S-001", name: "Oil Change + Filter Service", price: 4500, category: "Maintenance" },
  { id: "S-002", name: "Brake Pad Replacement", price: 6800, category: "Brakes" },
  { id: "S-003", name: "General Inspection", price: 500, category: "Diagnostic" },
  { id: "S-004", name: "Tire Rotation", price: 800, category: "Tires" },
  { id: "S-005", name: "Wheel Alignment", price: 1500, category: "Tires" },
  { id: "S-006", name: "AC Service", price: 2500, category: "AC" },
];

export function DataProvider({ children }: { children: ReactNode }) {
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [services, setServices] = useState<Service[]>(initialServices);
  const [vendors, setVendors] = useState<Vendor[]>(initialVendors);
  const [stockInRecords, setStockInRecords] = useState<StockInRecord[]>([]);
  const [vendorPayments, setVendorPayments] = useState<VendorPayment[]>([]);

  // --- Backend Emulation Logic ---

  /**
   * Adds a new invoice and performs necessary side effects:
   * 1. Updates Customer Spend and Visit History
   * 2. Deducts Stock for Products used
   */
  const addInvoice = (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber' | 'date' | 'servicesCount'>) => {
    // 1. Generate unique IDs (Emulating auto-increment)
    const newId = String(invoices.length + 1).padStart(3, '0');
    const newInvoiceNumber = `INV-${newId}`;
    const currentDate = new Date().toISOString().split('T')[0];
    
    // 2. Prepare the final invoice object
    const newInvoice: Invoice = {
      ...invoiceData,
      id: newId,
      invoiceNumber: newInvoiceNumber,
      date: currentDate,
      servicesCount: invoiceData.items.length
    };
    
    // 3. Update Invoices State
    setInvoices(prev => [newInvoice, ...prev]);
    
    // 4. "Backend" Side Effect: Update Customer History
    const customer = customers.find(c => c.id === invoiceData.customerId);
    if (customer) {
      updateCustomer(customer.id, {
        invoiceHistory: [...(customer.invoiceHistory || []), newId],
        totalSpent: customer.totalSpent + invoiceData.amount,
        lastVisit: currentDate,
        serviceHistory: customer.serviceHistory + 1,
      });
    } else {
      // If customer doesn't exist (Walk-in), we could optionally auto-create them here
      // But for this flow, we assume they are selected or created first
    }

    // 5. "Backend" Side Effect: Deduct Stock for each product in the invoice
    invoiceData.items.forEach(item => {
      if (item.type === 'product' && !item.customerSupplied) {
        // Find the product by name or ID if available
        const product = products.find(p => p.name === item.description);
        if (product) {
          deductStock(product.id, item.quantity);
        }
      }
    });
    
    console.log("Invoice Flow Complete: Saved invoice and updated related records.");
    return newInvoice;
  };

  const updateInvoice = (id: string, updates: Partial<Invoice>) => {
    setInvoices(prev => prev.map(inv => 
      inv.id === id ? { ...inv, ...updates } : inv
    ));
  };

  const deleteInvoice = (id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  const getInvoiceById = (id: string) => {
    return invoices.find(inv => inv.id === id);
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'lastVisit' | 'totalSpent' | 'serviceHistory' | 'vehicles'>) => {
    const newId = `CUST-${String(customers.length + 1).padStart(3, '0')}`;
    const newCustomer: Customer = {
      ...customerData,
      id: newId,
      lastVisit: 'N/A',
      totalSpent: 0,
      serviceHistory: 0,
      vehicles: 1, // Defaulting to 1 for initial creation
      status: 'Active'
    };
    
    setCustomers(prev => [...prev, newCustomer]);
    return newCustomer;
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomers(prev => prev.map(cust => 
      cust.id === id ? { ...cust, ...updates } : cust
    ));
  };

  const getCustomerById = (id: string) => {
    return customers.find(c => c.id === id);
  };

  const addProduct = (productData: Omit<Product, 'id' | 'status'>) => {
    const newId = `PROD-${String(products.length + 1).padStart(3, '0')}`;
    const status = productData.stockQuantity > 10 ? 'In Stock' : (productData.stockQuantity > 0 ? 'Low Stock' : 'Out of Stock');
    
    const newProduct: Product = {
      ...productData,
      id: newId,
      status: status
    };
    
    setProducts(prev => [...prev, newProduct]);
    return newProduct;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(prod => {
      if (prod.id === id) {
        const updated = { ...prod, ...updates };
        // Recalculate status based on new quantity
        if (updates.stockQuantity !== undefined) {
          updated.status = updated.stockQuantity > 10 ? 'In Stock' : (updated.stockQuantity > 0 ? 'Low Stock' : 'Out of Stock');
        }
        return updated;
      }
      return prod;
    }));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const deductStock = (productId: string, quantity: number) => {
    setProducts(prev => prev.map(prod => {
      if (prod.id === productId) {
        const newQuantity = Math.max(0, prod.stockQuantity - quantity);
        return {
          ...prod,
          stockQuantity: newQuantity,
          status: newQuantity > 10 ? 'In Stock' : (newQuantity > 0 ? 'Low Stock' : 'Out of Stock')
        };
      }
      return prod;
    }));
  };

  // Service Operations
  const addService = (serviceData: Omit<Service, 'id'>) => {
    const newId = `S-${String(services.length + 1).padStart(3, '0')}`;
    const newService: Service = {
      ...serviceData,
      id: newId,
    };
    setServices(prev => [...prev, newService]);
    return newService;
  };

  const updateService = (id: string, updates: Partial<Service>) => {
    setServices(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const deleteService = (id: string) => {
    setServices(prev => prev.filter(s => s.id !== id));
  };

  const addVendor = (vendorData: Omit<Vendor, 'id' | 'outstandingBalance' | 'totalSupplied' | 'totalPaid'>) => {
    const newId = `VEN-${String(vendors.length + 1).padStart(3, '0')}`;
    const newVendor: Vendor = {
      ...vendorData,
      id: newId,
      outstandingBalance: 0,
      totalSupplied: 0,
      totalPaid: 0,
    };
    
    setVendors(prev => [...prev, newVendor]);
    return newVendor;
  };

  const updateVendor = (id: string, updates: Partial<Vendor>) => {
    setVendors(prev => prev.map(vend => 
      vend.id === id ? { ...vend, ...updates } : vend
    ));
  };

  const deleteVendor = (id: string) => {
    setVendors(prev => prev.filter(vend => vend.id !== id));
  };

  const getVendorById = (id: string) => {
    return vendors.find(v => v.id === id);
  };

  const addStockIn = (stockInData: Omit<StockInRecord, 'id' | 'date'>) => {
    const newId = `STOCK-${String(stockInRecords.length + 1).padStart(3, '0')}`;
    const currentDate = new Date().toISOString().split('T')[0];
    
    const newStockIn: StockInRecord = {
      ...stockInData,
      id: newId,
      date: currentDate,
    };
    
    setStockInRecords(prev => [newStockIn, ...prev]);
    
    // Side effect: Update product quantities
    stockInData.items.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (product) {
        updateProduct(product.id, {
          stockQuantity: product.stockQuantity + item.quantity,
          lastCostPrice: item.costPrice
        });
      }
    });

    // Side effect: Update vendor's total supplied and balance
    const vendor = vendors.find(v => v.id === stockInData.vendorId);
    if (vendor) {
      updateVendor(vendor.id, {
        totalSupplied: vendor.totalSupplied + stockInData.totalAmount,
        outstandingBalance: vendor.outstandingBalance + stockInData.totalAmount,
        lastSupplyDate: currentDate,
      });
    }
    
    return newStockIn;
  };

  const getVendorStockIns = (vendorId: string) => {
    return stockInRecords.filter(rec => rec.vendorId === vendorId);
  };

  const addVendorPayment = (paymentData: Omit<VendorPayment, 'id' | 'date'>) => {
    const newId = `PAY-${String(vendorPayments.length + 1).padStart(3, '0')}`;
    const currentDate = new Date().toISOString().split('T')[0];
    
    const newPayment: VendorPayment = {
      ...paymentData,
      id: newId,
      date: currentDate,
    };
    
    setVendorPayments(prev => [newPayment, ...prev]);
    
    // Update vendor's outstanding balance and total paid
    const vendor = vendors.find(v => v.id === paymentData.vendorId);
    if (vendor) {
      updateVendor(vendor.id, {
        outstandingBalance: vendor.outstandingBalance - paymentData.amount,
        totalPaid: vendor.totalPaid + paymentData.amount,
        lastPaymentDate: currentDate,
      });
    }
    
    return newPayment;
  };

  const getVendorPayments = (vendorId: string) => {
    return vendorPayments.filter(pay => pay.vendorId === vendorId);
  };

  return (
    <DataContext.Provider value={{
      invoices,
      customers,
      products,
      services,
      vendors,
      stockInRecords,
      vendorPayments,
      addInvoice,
      updateInvoice,
      deleteInvoice,
      getInvoiceById,
      addCustomer,
      updateCustomer,
      getCustomerById,
      addProduct,
      updateProduct,
      deleteProduct,
      deductStock,
      addService,
      updateService,
      deleteService,
      addVendor,
      updateVendor,
      deleteVendor,
      getVendorById,
      addStockIn,
      getVendorStockIns,
      addVendorPayment,
      getVendorPayments,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
